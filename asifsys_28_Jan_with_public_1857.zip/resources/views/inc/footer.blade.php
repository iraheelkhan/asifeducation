   	<script src="asset('/jquery-3.2.1.min.js')}}"></script>
    <!-- Bootstrap JS-->
    <script src="asset('/bootstrap-4.1/popper.min.js')}}"></script>
    <script src="asset('/bootstrap-4.1/bootstrap.min.js')}}"></script>
    <!-- asset(' JS       -->
    <script src="{{ asset('js/slick.min.js')}}">
    </script>
    <script src="{{ asset('js/wow.min.js')}}"></script>
    <script src="{{ asset('js/animsition.min.js')}}"></script>
    <script src="{{ asset('js/bootstrap-progressbar.min.js')}}">
    </script>
    <script src="{{ asset('js/jquery.waypoints.min.js')}}"></script>
    <script src="{{ asset('js/jquery.counterup.min.js')}}">
    </script>
    <script src="{{ asset('js/circle-progress.min.js')}}"></script>
    <script src="{{ asset('js/perfect-scrollbar.js')}}"></script>
    <script src="{{ asset('js/Chart.bundle.min.js')}}"></script>
    <script src="{{ asset('js/select2.min.js')}}">
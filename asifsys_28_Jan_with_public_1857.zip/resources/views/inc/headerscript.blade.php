<link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/fontawesome-all.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/material-design-iconic-font.min.css')}}" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="{{asset('css/animation.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/bootstrap-progressbar-3.3.4.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/animate.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/hamburgers.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/slick.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/select2.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('css/perfect-scrollbar.css')}}" rel="stylesheet" media="all">
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResourcePerson extends Model
{
    //
}
